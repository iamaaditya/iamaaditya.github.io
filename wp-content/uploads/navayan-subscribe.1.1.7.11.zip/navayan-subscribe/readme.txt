=== Navayan Subscribe ===
Contributors: Amol Nirmala Waman
Tags: navayan, subscribe, subscribers, register, registration, mailing, email, wp subscribe, subscribe plugin, mailing list, subscribe email, notify, notification, widget, unsubscribe
Requires at least: 3+
Tested up to: 3.4.1
Stable tag: 1.1.7.1
Donate Link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=amolnw2778@gmail.com&item_name=NavayanSubscribe

Allows visitors to easily and quickly subscribe to your website/blog using email, name, additional field with Post notifications.

== Description ==
[Navayan Subscribe](http://blog.navayan.com/navayan-subscribe-easy-way-to-subscribe-wordpress-website-or-blog/) allows your website/blog visitors to easily and quickly register/subscribe to your website/blog using email, name and additional field.
Customize the subscribe form at Dashboard -> Tools -> Navayan Subscribe.
Or simply go to 'Appearance -> Widgets', drag and drop 'Navayan Subscribe' widget in your sidebar and see it in action.

**FEATURES**

* Visitors can subscribe
* Admin can also add subscribers
* Default form field - Email
* Extended form fields - Name and Custom field
* Custom form heading
* Custom subscribe button text
* Custom invalid email message
* Custom email exist message
* Custom success message
* Option to hide form after success
* Send new subscriber notification to admin
* Send new post notification to subscribers
* Sidebar Widget
* Option to use default form style
* Option to send post content in email
* Translate text support
* Subscriber gets Un-Subscribe link
* User can Un-Subscribe
* User gets removed if Un-Subscribed
* Checks whether user logged in or not
* Custom message if user is logged in
* Custom Un-Subscribe Message
* Checks if post is not already published

**Links:**
* [Plugin's Homepage](http://blog.navayan.com/navayan-subscribe-easy-way-to-subscribe-wordpress-website-or-blog/)
* [FAQs & Discussion](http://blog.navayan.com/navayan-subscribe-easy-way-to-subscribe-wordpress-website-or-blog/#comments)
* [Similar Topics](http://blog.navayan.com/category/wordpress/)
* [Navayan CSV Export](http://blog.navayan.com/navayan-csv-export-easiest-way-to-export-all-wordpress-table-data-to-csv-format/)


== Installation ==
1. Download 'Navayan Subscribe' wordpress plugin
2. Upload and Extract in `wp-content/plugins/` directory. Make sure 'wp-content' has write permission
3. Go to 'Dashboard -> Plugins' and activate it
4. Go to 'Dashboard -> Tools -> Navayan Subscribe'
5. Check notes or readme.txt for plugin usage with PHP code and Shortcode

**Links:**
* [Plugin's Homepage](http://blog.navayan.com/navayan-subscribe-easy-way-to-subscribe-wordpress-website-or-blog/)
* [FAQs & Discussion](http://blog.navayan.com/navayan-subscribe-easy-way-to-subscribe-wordpress-website-or-blog/#comments)
* [Similar Topics](http://blog.navayan.com/category/wordpress/)
* [CSV Export](http://blog.navayan.com/navayan-csv-export-easiest-way-to-export-all-wordpress-table-data-to-csv-format/)


== Usage ==
1. Activate the plugin
2. Go to Dashboard -> Tools -> Navayan Subscribe
3. Customize the form settings you want
4. Add this code:

`<?php
   if ( function_exists('navayan_subscribe') ){
      echo navayan_subscribe();
   }
?>`

to your PHP template page. Mostly it goes to `footer.php` file or put this shortcode `[navayan_subscribe]` in your post/page

And if you want to change the form UI (if needed) tweak your style.css as follows:
`#ny_subscribe_wrapper label { width: 100px !important}
#ny_subscribe_wrapper input[type="text"] { width: 120px !important}`

If you want to display Navayan Subscribe form in sidebar then go to 'Appearance -> Widgets', drag and drop 'Navayan Subscribe' widget in your sidebar.

**Links:**
* [Plugin's Homepage](http://blog.navayan.com/navayan-subscribe-easy-way-to-subscribe-wordpress-website-or-blog/)
* [FAQs & Discussion](http://blog.navayan.com/navayan-subscribe-easy-way-to-subscribe-wordpress-website-or-blog/#comments)
* [Similar Topics](http://blog.navayan.com/category/wordpress/)
* [Export WP to CSV](http://blog.navayan.com/navayan-csv-export-easiest-way-to-export-all-wordpress-table-data-to-csv-format/)


== Screenshots ==
1. Plugin listed under Tools tab
2. Basic subscribe form with email only
3. Extended subscribe form
4. Navayan Subscribe form settings
5. Subscribe form for admin


== Changelog ==

= 1.1.7.1 (20120707) =
* FIX: PHP warning

= 1.1.7 (20120706) =
* FIX: Avoided various filters
* FIX: Optimized the code

= 1.1.6 (20120605) =
* NEW: Custom message if user is logged in
* FIX: Checks if post is not already published
* FIX: Two typos

= 1.1.5 (20120519) =
* NEW: Translate text support
* NEW: Checks whether user logged in or not
* NEW: User can Un-Subscribe
* NEW: Subscriber gets Un-Subscribe link
* NEW: User gets removed if Un-Subscribed
* NEW: Custom Un-Subscribe Message
* FIX: Enhanced post notifications
* FIX: Widget title support

= 1.1.4.3 (20120408) =
* NEW: Option to send post content in email
* FIX: Filtered Username

= 1.1.4.2 (20120330) =
* NEW: Option to use default style
* FIX: Sidebar widget form field width

= 1.1.4.1 (20120317) =
* NEW: Altered post fetch criteria

= 1.1.4 (20120316) =
* NEW: Sidebar Widget

= 1.1.3 (20120315) =
* NEW: Added Feature list

= 1.1.2 (20120314) =
* NEW: New published post notification email to subscribers

= 1.1.1 (20120303) =
* NEW: Added support for subscribe notification email to admin

= 1.1 (20120302) =
* NEW: Added shortcode `[navayan_subscribe]` support

= 1.0 (20120229) =
* Compatible with wordpress 3.3+
* Minimum subscribe form
* Extended subscribe form
* Wordpress admin itself can add subscribers
* Form settings to customize the subscribe form


== Donate ==

We call 'Donation' as 'Dhammadana'. It help us to contribute more to open source community.
[Donate ie. Dhammadana](https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=amolnw2778@gmail.com&item_name=NavayanSubscribe)