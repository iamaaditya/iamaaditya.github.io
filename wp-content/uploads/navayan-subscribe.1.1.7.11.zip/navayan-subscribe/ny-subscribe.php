<?php
/*
Plugin Name: Navayan Subscribe
Description: <strong>Navayan Subscribe</strong> allows your website/blog visitor to easily and quickly register to your website/blog using email, name and additional field. Send subscribe notification to admin and new post notification to subscribers.
Version: 1.1.7.1
Usage: Paste this single line code within PHP tag in your template: if ( function_exists('navayan_subscribe') ){ echo navayan_subscribe(); } or put shortcode [navayan_subscribe] in post/page
Donate Link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=amolnw2778@gmail.com&item_name=NavayanSubscribe
Author: Amol Nirmala Waman
Plugin URI: http://blog.navayan.com/
Author URI: http://www.navayan.com/
*/

include('ny-subscribe-define.php');

/************************ ADMIN MENU UNDER 'TOOLS' TAB *********************/
function ny_subscribe_init() {
	if (function_exists('add_options_page')) {
		add_management_page( __( NY_PLUGIN_SUBSCRIBE_NAME, NY_PLUGIN_SUBSCRIBE_SLUG ), __( NY_PLUGIN_SUBSCRIBE_NAME, NY_PLUGIN_SUBSCRIBE_SLUG ), 'manage_options', NY_PLUGIN_SUBSCRIBE_SLUG, 'ny_subscribe_admin');
	}
}
add_action('admin_menu','ny_subscribe_init');
/************************ ADMIN MENU UNDER 'TOOLS' TAB ENDS *********************/

$admin_fields = array(
  array( 'slug' => '', 'type' => 'title', 'label'=> __('Form Settings'), 'val' => '' ),
  array(
		'slug'	=> 'ny_subscribe_field_form_heading',
		'type'	=> 'text',
		'label'	=> __('Form Heading'),
		'val'		=> __('Subscribe')
	),
	array(
		'slug'	=> 'ny_subscribe_field_label',
		'type'	=> 'text',
		'label'	=> __('Submit Button text'),
		'val'		=> __('Subscribe')
	),
	array(
		'slug'	=> 'ny_subscribe_field_show_name',
		'type'	=> 'checkbox',
		'label'	=> __('Display Name field?'),
		'val'		=> 0
	),
	array(
		'slug'	=> 'ny_subscribe_field_custom',
		'type'	=> 'text',
		'label'	=> __('Type Custom field you want to display'),
		'val'		=> ''
	),
	array(
		'slug'	=> 'ny_subscribe_field_email_invalid',
		'type'	=> 'text',
		'label'	=> __('Invalid email message'),
		'val'		=> __('Invalid Email')
	),
	array(
		'slug'	=> 'ny_subscribe_field_email_exist',
		'type'	=> 'text',
		'label'	=> __('Email exist message'),
		'val'		=> __('This Email already registered')
	),
	array(
		'slug'	=> 'ny_subscribe_field_success',
		'type'	=> 'text',
		'label'	=> __('Success message'),
		'val'		=> __('Thank you for subscribing!')
	),
	array(
		'slug'	=> 'ny_subscribe_field_hide_form',
		'type'	=> 'checkbox',
		'label'	=> __('Hide form after success?'),
		'val'		=> 1
	),
	array(
		'slug'	=> 'ny_subscribe_style',
		'type'	=> 'checkbox',
		'label'	=> __('Use default style for Navayan Subscribe form on Page, Post, Widget?'),
		'val'		=> 0
	),
	array(
		'slug'	=> 'ny_subscribe_logged_in_msg',
		'type'	=> 'text',
		'label'	=> __('Display a message if user is logged in'),
		'val'		=> __('You are already joined us!')
	),
	
  array( 'slug' => '', 'type' => 'title', 'label'=> __('Email Settings'), 'val' => '' ),  
  array(
		'slug'	=> 'ny_subscribe_field_send_email',
		'type'	=> 'checkbox',
		'label'	=> __('Send email to admin after every subscribe'),
		'val'		=> 0,
    'wrap'  => 'notify'
	),
	array(
		'slug'	=> 'ny_subscribe_field_new_post_content',
		'type'	=> 'checkbox',
		'label'	=> __('Send Post Content in email'),
		'val'		=> 0,
    'wrap'  => 'notify'
	),
  array( 'slug' => '', 'type' => 'title', 'label'=> __('Un-Subscribe Message'), 'val' => '' ),  
  array(
		'slug'	=> 'ny_unsubscribe_message',
		'type'	=> 'textarea',
		'label'	=> __('This message will be displayed on <strong>Navayan Unsubscribe</strong> page'),
		'val'		=> __('You are successfully unsubscribed!')
	),
  array( 'slug' => '', 'type' => 'title', 'label'=> __('Notify Subscribers for:'), 'val' => '' )
);


//if (has_filter('publish_post') ){
  $ar_publish = array(
    array(
      'slug'	=> 'ny_subscribe_field_notify_published_post',
      'type'	=> 'checkbox',
      'label'	=> __('Natural Puiblished Post (before auto save)'),
      'val'		=> 0,
      'wrap'  => 'notify'
    )
  );
//}
//if (has_filter('new_to_publish') ){
  $ar_new = array(
    array(
      'slug'	=> 'ny_subscribe_field_notify_new_post',
      'type'	=> 'checkbox',
      'label'	=> __('New to Puiblished Post (after auto save)'),
      'val'		=> 0,
      'wrap'  => 'notify'
    )
  );
//}
//if (has_filter('draft_to_publish') ){
  $ar_draft = array(
    array(
      'slug'	=> 'ny_subscribe_field_notify_draft_post',
      'type'	=> 'checkbox',
      'label'	=> __('Draft to Puiblished Post'),
      'val'		=> 0,
      'wrap'  => 'notify'
    )
  );
//}
//if (has_filter('pending_to_publish') ){
  $ar_pending = array(
    array(
      'slug'	=> 'ny_subscribe_field_notify_pending_post',
      'type'	=> 'checkbox',
      'label'	=> __('Pending to Puiblished Post'),
      'val'		=> 0,
      'wrap'  => 'notify'
    )
  );
//}
//if (has_filter('publish_future_post') ){
  $ar_future = array(
    array(
      'slug'	=> 'ny_subscribe_field_notify_future_post',
      'type'	=> 'checkbox',
      'label'	=> __('Future to Puiblished Post'),
      'val'		=> 0,
      'wrap'  => 'notify'
    )
  );
//}
//if (has_filter('private_to_publish') ){
  $ar_private = array(
    array(
      'slug'	=> 'ny_subscribe_field_notify_private_post',
      'type'	=> 'checkbox',
      'label'	=> __('Private to Puiblished Post'),
      'val'		=> 0,
      'wrap'  => 'notify'
    )
  );
//}
//if (has_filter('xmlrpc_publish_post') ){
  $ar_xmlrpc = array(
    array(
      'slug'	=> 'ny_subscribe_field_notify_xmlrpc_post',
      'type'	=> 'checkbox',
      'label'	=> __('XMLRPC to Puiblished Post'),
      'val'		=> 0,
      'wrap'  => 'notify'
    )
  );
//}
  
$admin_fields = array_merge ( $admin_fields, $ar_publish, $ar_new, $ar_draft, $ar_pending, $ar_future, $ar_private, $ar_xmlrpc );


/************************ EXTEND USERMETA **************************/
function ny_subscribe_extend_contact( $contactmethods ) {
  $contactmethods[ 'ny_subscribe_field_custom' ] = get_option( 'ny_subscribe_field_custom' );
  return $contactmethods;
}
add_filter('user_contactmethods','ny_subscribe_extend_contact',10,1);
/************************ EXTEND USERMETA ENDS **************************/

/************************ GLOBAL VARS **************************/
$init_global = array();
$init_global['form_heading']	= get_option( 'ny_subscribe_field_form_heading' )		? stripslashes( get_option( 'ny_subscribe_field_form_heading' ) ) : __('Subscribe');
$init_global['submit_label']	= get_option( 'ny_subscribe_field_label' )					? stripslashes( get_option( 'ny_subscribe_field_label' ) ) : __('Subscribe');
$init_global['show_name']			= get_option( 'ny_subscribe_field_show_name' );
$init_global['show_custom']		= get_option( 'ny_subscribe_field_custom' );
$init_global['email_error']		= get_option( 'ny_subscribe_field_email_invalid' )	? stripslashes( get_option( 'ny_subscribe_field_email_invalid' ) ) : __('Invalid Email');
$init_global['email_exist']		= get_option( 'ny_subscribe_field_email_exist' )		? stripslashes( get_option( 'ny_subscribe_field_email_exist' ) ) : __('This Email already registered');
$init_global['msg_success']		= get_option( 'ny_subscribe_field_success' )				? stripslashes( get_option( 'ny_subscribe_field_success' ) ) : __('Thank you for subscribing!');
$init_global['send_email']		= get_option( 'ny_subscribe_field_send_email' );
$init_global['notify_published_post'] = get_option( 'ny_subscribe_field_notify_published_post' );
$init_global['notify_new_post']       = get_option( 'ny_subscribe_field_notify_new_post' );
$init_global['notify_draft_post']     = get_option( 'ny_subscribe_field_notify_draft_post' );
$init_global['notify_pending_post']   = get_option( 'ny_subscribe_field_notify_pending_post' );
$init_global['notify_future_post']    = get_option( 'ny_subscribe_field_notify_future_post' );
$init_global['notify_private_post']   = get_option( 'ny_subscribe_field_notify_private_post' );
$init_global['notify_xmlrpc_post']    = get_option( 'ny_subscribe_field_notify_xmlrpc_post' );
$init_global['ny_unsubscribe_message']	= get_option( 'ny_unsubscribe_message' ) ? stripslashes( get_option( 'ny_unsubscribe_message' ) ) : __('You are successfully unsubscribed!');
$init_global['ny_subscribe_logged_in_msg']	= get_option( 'ny_subscribe_logged_in_msg' ) ? stripslashes( get_option( 'ny_subscribe_logged_in_msg' ) ) : __('You are already joined us!');

$val_name=''; $val_email=''; $val_custom='';
/************************ GLOBAL VARS ENDS **************************/

/************************ FORM FIELDS **************************/
function ny_subscribe_form_fields(){
	global $val_name, $val_email, $val_custom, $init_global;
	
	if( $init_global['show_name'] == 1){
		echo "<p>
			<label for='ny_name'>".__('Name')."</label>
			<input type='text' name='ny_name' id='ny_name' value='". stripslashes( $val_name ) ."' />
		</p>";
	}
	
	echo "<p>
		<label for='ny_email'>".__('Email')."</label>
		<input type='text' name='ny_email' id='ny_email' value='". stripslashes( $val_email ) ."' />
	</p>";
	
	if( $init_global['show_custom'] ){
		echo "<p>
			<label for='ny_custom'>". __( $init_global['show_custom'] ) ."</label>
			<input type='text' name='ny_custom' id='ny_custom' value='". stripslashes( $val_custom ) ."' />
		</p>";
	}
	
}
/************************ FORM FIELDS ENDS **************************/

/************************ TOTAL SUBSCRIBERS COUNT **************************/
function ny_subscriber_count(){
	global $wpdb;
	$u = mysql_fetch_array(mysql_query("SELECT COUNT(umeta_id) AS num FROM ".$wpdb->prefix."usermeta WHERE meta_key='".$wpdb->prefix."capabilities' AND meta_value LIKE '%subscriber%' "));
	return $u['num'];
}

/************************ CHECKS IF 'Navayan Unsubscribe' PAGE EXIST **************************/
global $wpdb;
$unsubscribe_exist = mysql_fetch_array(mysql_query("SELECT ID FROM ".$wpdb->prefix."posts WHERE post_name='navayan-unsubscribe' LIMIT 1"));
$unsubscribe_page_id = $unsubscribe_exist['ID'];

if (!$unsubscribe_page_id){ # IF NOT EXIST, CREATE ONE
  wp_insert_post( array(
		'post_title' => 'Navayan Unsubscribe',
		'post_status' => 'publish', 
		'post_type' => 'page',
		'post_author' => 1,
		'post_content' => '[navayan_unsubscribe]'
	));
}
/************************ CHECKS IF 'Navayan Unsubscribe' PAGE EXIST ENDS **************************/

// GENERATE UN-SUBSCRIBE LINK
if ( $unsubscribe_page_id ){
  if ( !function_exists( 'fn_unsubscribe' ) ){
    function fn_unsubscribe( $setUnsubscribeEmail ){
      global $unsubscribe_text, $unsubscribe_page_id;
      $unsubscribe_text = "<tr>
                            <td>
                              <p>
                                <small>
                                  <a href='". get_option('siteurl')."/?page_id=".$unsubscribe_page_id . "?email=" . $setUnsubscribeEmail ."' target='_blank'>" . __('Unsubscribe') . "</a> "
                                  .__('If you do not want to receive any more post notification.') . " 
                                </small>
                              </p>
                            </td>
                          </tr>";
      return $unsubscribe_text;
      # LINK WILL BE:  http://yoursite.com/?page_id=navayan-unsubscribe page id?email=unsubscriber'semail 
    }
  }
}



/*********************** SEND NEW POST NOTIFICATION TO SUBSCRIBERS ********************/
function ny_subscribe_notify_post($post_id) {
	global $wpdb, $unsubscribe_page_id;
	$new_post = get_post( $post_id );
	if ( $new_post->post_status != 'publish'){	// TO DO - is this causing an issue?
		$send_post_content = get_option('ny_subscribe_field_new_post_content') == 1 ? $new_post->post_content : '';
		$blogname	= get_option('blogname');	
		$from			= get_option('admin_email'); # check for current user
		ini_set("sendmail_from","<$from>");
		$subject	= __("New post at ". $blogname);
		$headers  = "MIME-Version: 1.0 \r\n";
		$headers .= "Content-type: text/html; charset=utf-8 \r\n";
		$headers .= "From: $blogname <$from>\r\n";

		$subscriber_query = mysql_query("SELECT ID, user_login, user_email
																				FROM ".$wpdb->prefix."users u, ".$wpdb->prefix."usermeta um
																				WHERE um.meta_key='".$wpdb->prefix."capabilities'
																				AND um.meta_value LIKE '%subscriber%'
																				AND um.user_id = u.ID ") or die(mysql_error());
		
		while ($ny_subscribers = mysql_fetch_array($subscriber_query)){
			$uname = get_user_meta ($sub_list['ID'], 'first_name');
			$uname = $uname != '' ? $uname : $ny_subscribers['user_login'];		
			$message = "<html>
										<head></head>
										<body>
											<table cellpadding='0' cellspacing='0' border='0'>
												<tr>
													<td>".__('Hi ') . stripslashes( $uname ) ."!</td>
												</tr>
												<tr>
													<td>
														<p>".__('A new post has been published at ') . $blogname."
														<p>".__('Please check'). " <a href='". get_post_permalink( $new_post->ID ) ."' target='_blank'>". __($new_post->post_title) ."</a></p>
														". __($send_post_content) ."
													</td>
												</tr>";
			
			# APPEND UN-SUBSCRIBE LINK
			if ( $unsubscribe_page_id ){
				if ( function_exists( 'fn_unsubscribe' ) ){
					$message .= fn_unsubscribe( $ny_subscribers['user_email'] );
				}
			}
			
			$message .= " </table>
										</body>
									</html>";

			@wp_mail( $ny_subscribers['user_email'], $subject, $message, $headers );
		}
	}
}


/************************ SEND NEW POST NOTIFICATION TO SUBSCRIBERS **************************/
if ( $init_global['notify_published_post']	== 1 ) add_action( 'publish_post', 'ny_subscribe_notify_post', 10,1 );
if ( $init_global['notify_new_post']				== 1 ) add_action( 'new_to_publish', 'ny_subscribe_notify_post', 10,1 );
if ( $init_global['notify_draft_post']			== 1 ) add_action( 'draft_to_publish', 'ny_subscribe_notify_post', 10,1 );
if ( $init_global['notify_pending_post']		== 1 ) add_action( 'pending_to_publish', 'ny_subscribe_notify_post', 10,1 );
if ( $init_global['notify_future_post']			== 1 ) add_action( 'publish_future_post', 'ny_subscribe_notify_post', 10,1 );
if ( $init_global['notify_private_post']		== 1 ) add_action( 'private_to_publish', 'ny_subscribe_notify_post', 10,1 );
if ( $init_global['notify_xmlrpc_post']			== 1 ) add_action( 'xmlrpc_publish_post', 'ny_subscribe_notify_post', 10,1 );


/************************ ADD SUBSCRIBER **************************/
function ny_add_subscriber($add = true){
  global $val_name, $val_email, $val_custom, $init_global;
  $return='';

  /************************** VALIDATING FORM AND SAVING IT INTO DB ********************/
  if( isset($_POST['ny_subscribe_submit']) ){
    require_once( ABSPATH . WPINC . '/formatting.php');
    require_once( ABSPATH . WPINC . '/user.php');

    $val_email	= isset($_POST['ny_email']) ? $_POST['ny_email'] : '';
    if( $init_global['show_name'] == 1){ 
      $val_name		= isset($_POST['ny_name']) ? $_POST['ny_name'] : '';
    }
    if( $init_global['show_custom'] ){
      $val_custom	= isset($_POST['ny_custom']) ? $_POST['ny_custom'] : '';
    }

    if ( !is_email( $val_email ) ) {
      $return['err'] = true;
      $return['msg'] = $init_global['email_error'];
    } elseif ( email_exists( $val_email ) ){			
      $return['err'] = true;
      $return['msg'] = $init_global['email_exist'];
    } else {

      if ( $init_global['show_name'] == 1 && $val_name == ''){
        $return['err'] = true;
        $return['msg'] = __('Type name');
      } elseif ( $init_global['show_custom'] && $val_custom == ''){					
        $return['err'] = true;
        $return['msg'] = __('Required '. $init_global['show_custom'] );
      } else {

          $val_name			= mysql_real_escape_string($val_name);
          $val_custom		= sanitize_user( str_replace('@',' ', $val_custom ) );
          $clean_login	= sanitize_user( $val_email );

          $val_pass			= substr( md5( uniqid( microtime() ) ), 0, 7); # TODO - PASSWORD
          $val_id				= wp_create_user( $clean_login, $val_pass, $val_email );
          $user = new WP_User($val_id);
          $user->set_role('subscriber');

          if ( !$val_id ){
            $return['err'] = true;
            $return['msg'] = __('Unable to subscribe');
          }else{
            update_user_meta( $user->ID, 'ny_subscribe_field_custom', $val_custom );
            update_user_meta( $user->ID, 'first_name', $val_name );

            # SEND PLAIN EMAIL TO ADMIN AFTER EVERY SUBSCRIBE
            if( $init_global['send_email'] == 1 && $add == false){							
              $message = __("New member subscribed to your website/blog ". get_option('blogname') );
              if ( $init_global['show_name'] == 1 ){
                $message .= __("<br/>Name: ". $val_name );
              }
              $message .= __("<br/>Email: ". $val_email );
              if ( $init_global['show_custom'] == 1 ){
                $message .= __("<br/>". $init_global['show_custom'] .": ". $val_custom );
              }

              $headers  = "MIME-Version: 1.0 \r\n";
              $headers .= "Content-type: text/plain; charset=utf-8 \r\n";
              $headers .= "From: ". NY_PLUGIN_SUBSCRIBE_NAME;

              if ( !is_admin() ){
                @wp_mail( get_option('admin_email'), __("New Subscriber!"), $message, $headers );
              }
            }

            $return['err'] = false;
            $return['msg'] = $add == true ? __('Subscriber added!') : stripslashes( $init_global['msg_success'] );
          }
      }
    }

    $cls = $return['err'] == true ? 'nys-error' : 'nys-success';
    echo '<p class="'.$cls.' nybox"> '. $return['msg'] .' </p>';
    if($return['err'] == false && $add == false){
      if(get_option( 'ny_subscribe_field_hide_form' ) == 1){
        echo '<style type="text/css">#ny_subscribe_form{display:none}</style>';
      }
      echo '<script type="text/javascript">
              if(jQuery){
                jQuery(function ($){
                  $("#ny_subscribe_form input:text").val("");
                });
              }
            </script>';
    }

  }
}# ny_add_subscriber


/************************ NAVAYAN SUBSCRIBE FORM SETTINGS **************************/
function ny_subscribe_admin() {
	global $admin_fields;
	$fields_count = sizeof($admin_fields);	
?>

<link rel="stylesheet" type="text/css" href="<?php echo NY_PLUGIN_SUBSCRIBE_DIR; ?>ny-admin-ui.css" />

<div id="wrapper">
	<div class="titlebg" id="plugin_title">
		<span class="head i_mange_coupon"><h1><?php echo NY_PLUGIN_SUBSCRIBE_NAME;?></h1></span>
	</div>
	<div id="page">
		<p>
			<a href="<?php echo NY_PLUGIN_URL; ?>navayan-subscribe-easy-way-to-subscribe-wordpress-website-or-blog/" target="_blank"><?php _e("Plugin's Homepage"); ?></a> &nbsp; 
			<a href="<?php echo NY_PLUGIN_URL; ?>navayan-subscribe-easy-way-to-subscribe-wordpress-website-or-blog/#comments" target="_blank"><?php _e('FAQs &amp; Discussion');?></a> &nbsp; 
			<a href="<?php echo NY_PLUGIN_URL; ?>category/wordpress/" target="_blank"><?php _e('Similar Topics');?></a> &nbsp; 
			<a href="<?php echo NY_PLUGIN_URL; ?>navayan-csv-export-easiest-way-to-export-all-wordpress-table-data-to-csv-format/" target="_blank"><?php _e('Export Users to CSV');?></a> &nbsp; 
			<a href="<?php echo NY_DONATE_SUBSCRIBE_LINK; ?>" target="_blank"><?php _e('Donate');?></a>
		</p>
		<div class="ny-left">						
			<div class="ny-left-widgets">				 
				<form id="ny_subscribe_admin_form" action="#wrapper" method="post">
					<fieldset class="nybox">
						<legend><?php _e('Settings');?></legend>
						
						<?php
							/************************** ADD NAVAYAN SUBSCRIBE FORM FIELDS IF NOT EXIST **************************/
							for($i = 0; $i < $fields_count; $i++){
								if( !get_option( $admin_fields[$i]['slug'] ) ){
									update_option( $admin_fields[$i]['slug'], $admin_fields[$i]['val'] );
								}
							}
							
							/************************** SAVE VALUES ***************************/
							if( isset($_POST['ny_subscribe_field_submit']) ){								
								for ( $i = 0; $i < $fields_count; $i++ ){
									if ( $admin_fields[$i]['type'] == 'checkbox' ){
										$mine[$i]['value'] = isset($_POST[ $admin_fields[$i]['slug'] ]) ? 1 : 0;
									}else{
										$mine[$i]['value'] = @$_POST[$admin_fields[$i]['slug']];
									}
									update_option( $admin_fields[$i]['slug'], $mine[$i]['value'] );
								}
								echo '<p class="nys-success nybox">'. __('Settings saved!') . '</p>';
							}
							
							/************************** DISPLAY FIELDS **************************/
							for ( $i = 0; $i < $fields_count; $i++ ){
                if ( $admin_fields[$i]['type'] == 'title' ){
                  echo '<h3>'. __( $admin_fields[$i]['label'] ) .'</h3>';
                }else{
                  $checked = get_option($admin_fields[$i]['slug']) == '1' ? 'checked="checked"' : '';
                  if ( $admin_fields[$i]['wrap'] == 'notify' ){
                    echo '<label class="'. $admin_fields[$i]['wrap'] .'" for="'. $admin_fields[$i]['slug'] .'">';
                    echo '<input '. $checked .' type="'. $admin_fields[$i]['type'] .'" name="'. $admin_fields[$i]['slug'] .'" id="'. $admin_fields[$i]['slug'] .'" value="'. get_option( $admin_fields[$i]['slug'] ) .'" />';
                    echo __( $admin_fields[$i]['label'] );
                    echo '</label>';                    
                  }elseif ( $admin_fields[$i]['type'] == 'textarea' ) {
                    echo '<p>';
                    echo '<label for="'. $admin_fields[$i]['slug'] .'" style="vertical-align:top">'. __( $admin_fields[$i]['label'] ) .'</label>';
                    echo '<textarea name="'. $admin_fields[$i]['slug'] .'" id="'. $admin_fields[$i]['slug'] .'">'. stripslashes( get_option( $admin_fields[$i]['slug'] ) ) .'</textarea>';
                    echo '</p>';
                  }else{
                    echo '<p>';
                    echo '<label for="'. $admin_fields[$i]['slug'] .'">'. __( $admin_fields[$i]['label'] ) .'</label>';
                    echo '<input '. $checked .' type="'. $admin_fields[$i]['type'] .'" name="'. $admin_fields[$i]['slug'] .'" id="'. $admin_fields[$i]['slug'] .'" value="'. stripslashes( get_option( $admin_fields[$i]['slug'] ) ) .'" />';
                    echo '</p>';
                  }
                }
							}
						?>
						
						<p>
							<label>&nbsp;</label>
							<input type="submit" name="ny_subscribe_field_submit" id="ny_subscribe_field_submit" value="<?php _e('Save Settings');?>" class="button-primary" />
						</p>
					</fieldset>
				</form>
				
				
				<form id="ny_subscribe_add_form" action="#wrapper" method="post">
					<fieldset class="nybox">
						<legend><?php _e('Add Subscriber');?></legend>
						<?php
							global $val_name, $val_email, $val_custom, $init_global;	
							ny_add_subscriber($add = true);
							echo "<p><b><a href='users.php?role=subscriber'>".__('Total subscribers'). "</a>: ".ny_subscriber_count()."</b></p>";
							ny_subscribe_form_fields();
						?>
						<p>
							<label>&nbsp;</label>
							<input type="submit" name="ny_subscribe_submit" id="ny_subscribe_submit" value="<?php _e('Add Subscriber');?>" class="button-primary" />
						</p>
					</fieldset>
				</form>
				
				
			</div>
    </div><!-- .ny-left -->
          
		<div class="ny-right">
			<?php if( function_exists('ny_subscribe_widgets')) ny_subscribe_widgets(); ?>
		</div><!-- .ny-right -->
		
	</div>
</div>

	
<?php
}
/************************ NAVAYAN SUBSCRIBE FORM SETTINGS ENDS **************************/


/************************** SUBSCRIBE FORM UI ********************/
if ( !function_exists('navayan_subscribe') ){	
	function navayan_subscribe(){
    
    // EXCLUDE SUBSCRIBE FORM FOR LOGGED IN USER
    if ( !is_user_logged_in() ) {    
      if ( !get_option('ny_subscribe_style') ){
        wp_enqueue_style( '', NY_PLUGIN_SUBSCRIBE_DIR . 'ny-admin-ui.css' );
      }
      $wrapper_id = 'ny_subscribe_wrapper';
      echo "<div id='". $wrapper_id ."'>";

      global $val_name, $val_email, $val_custom, $init_global;	
      ny_add_subscriber($add = false);	

      echo "<form name='ny_subscribe_form' id='ny_subscribe_form' method='post' action='#". $wrapper_id ."'>";
      echo "<h3>". stripslashes( $init_global['form_heading'] ) ."</h3>";

            ny_subscribe_form_fields();

      echo "<p>
            <label>&nbsp;</label>
            <input type='submit' value='". stripslashes( $init_global['submit_label'] ) ."' name='ny_subscribe_submit' id='ny_subscribe_submit' />
          </p>
        </form>
      </div>";
    }else{
			echo "<div id='userloggedin' class='widget'>";
			_e( "<h2 class='title'>". stripslashes( $init_global['form_heading'] ) ."</h2>" );
			_e( "<h4>". stripslashes( $init_global['ny_subscribe_logged_in_msg'] ) ."</h4>" );
			echo '</div>';
		}
	}
	add_shortcode('navayan_subscribe', 'navayan_subscribe');
}
/************************** SUBSCRIBE FORM UI ENDS ********************/	


/************************** NAVAYAN UNSUBSCRIBE AND DELETE SUBSCRIBER ********************/
if ( !function_exists('navayan_unsubscribe') ){	
	function navayan_unsubscribe(){
    global $unsubscribe_exist, $wpdb, $init_global;

		# CHECK IF USER EXIST && USER IS NOT LOGGED IN && 'Navayan Unsubscribe' PAGE EXIST
    if ( $unsubscribe_exist && !is_user_logged_in() && is_page('navayan-unsubscribe') ) {
			$uri = $_SERVER['REQUEST_URI'];
			$uri = explode('?email=', $uri);
			if ( $uri[1] && is_email ( $uri[1] ) ){ # CHECK QUERY STRING AND VALID EMAIL
				$get_subscriber_id = $wpdb->get_var ("SELECT ID FROM $wpdb->users WHERE user_email = '" . $uri[1] . "' LIMIT 1");
				if ( $get_subscriber_id ){ # CHECK SUBSCRIBER EXIST FIRST AND THEN DO OPERATION
					require_once './wp-admin/includes/user.php';
					$deleteSubscriber = wp_delete_user( $get_subscriber_id );
					if ( $deleteSubscriber ){ # IF SUCCESSFULLY UNSUBSCRIBED, SHOW MESSAGE
						_e( $init_global['ny_unsubscribe_message'] );
					}
				}
			}
    }
	}
	add_shortcode('navayan_unsubscribe', 'navayan_unsubscribe');
}
/************************** NAVAYAN UNSUBSCRIBE AND DELETE SUBSCRIBER ENDS ********************/	


/************************** NAVAYAN SUBSCRIBE WIDGET IN SIDEBAR ********************/	
class ny_subscribe_widget extends WP_Widget {
  public function __construct() {
    global $init_global;
		$this->WP_Widget(
      2,
			'',
			array(
        'name' => __( stripslashes( $init_global['form_heading'] ) ), # FORM HEADING = WIDGET HEADING
        'description' => __('Displays Navayan Subscribe form as a widget in your sidebar', 'nysubscribe')
      )
		);
	}

	public function widget( $args ) {
		extract($args);
		if ( function_exists('navayan_subscribe') ){	
			navayan_subscribe();
		}
	}
}

add_action('widgets_init', 'ny_subscribe_widget_init');
function ny_subscribe_widget_init() {
	register_widget('ny_subscribe_widget');
}




?>