<?php
	# DEFINES
	define('NY_PLUGIN_SUBSCRIBE_LOCATION', 'http://wordpress.org/extend/plugins/navayan-subscribe');
	define('NY_PLUGIN_SUBSCRIBE_NAME', __('Navayan Subscribe') );
	define('NY_PLUGIN_SUBSCRIBE_SLUG', 'navayan-subscribe');
	define('NY_PLUGIN_SUBSCRIBE_DIR', WP_PLUGIN_URL.'/'.NY_PLUGIN_SUBSCRIBE_SLUG.'/');	
	define('NY_PLUGIN_SUBSCRIBE_INFO', __('Allows your website/blog visitor to easily and quickly register to your website/blog using email, name and additional field. Send subscribe notification to admin.') );
  define('NY_PLUGIN_SUBSCRIBE_ABOUT', '<a href="'.NY_PLUGIN_SUBSCRIBE_LOCATION.'" target="_blank">'.NY_PLUGIN_SUBSCRIBE_NAME.'</a> '. __('allows your WordPress website/blog visitor to easily and quickly register to your website/blog using email, name and additional field. You can customize the form, fields and message with notifications.') );
	if( !defined('NY_PLUGIN_AUTHOR') ) define('NY_PLUGIN_AUTHOR', 'Amol Nirmala Waman');
	if( !defined('NY_AUTHOR_EMAIL') ) define('NY_AUTHOR_EMAIL', 'amolnw2778@gmail.com');
	if( !defined('NY_PLUGIN_URL') ) define('NY_PLUGIN_URL', 'http://blog.navayan.com/');
	if( !defined('NY_SITE') ) define('NY_SITE', 'navayan.com');
	if( !defined('NY_DONATE_TEXT') ) define('NY_DONATE_TEXT', __('We call \'Donation\' as \'<strong><em>Dhammadana</em></strong>\'. It help us to contribute more to open source community.') );
	if( !defined('NY_PAYPAL') ) define('NY_PAYPAL', 'https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=amolnw2778@gmail.com&item_name=');
	if( !defined('NY_DONATE_SUBSCRIBE_LINK') ) define('NY_DONATE_SUBSCRIBE_LINK', NY_PAYPAL . str_replace(' ', '', NY_PLUGIN_SUBSCRIBE_NAME) );
?>
<?php function ny_subscribe_widgets(){ ?>
	<div class="ny-widgets nybox">
		<h3>About</h3>
		<div class="ny-widgets-desc">
			<p id="navayan_logo"><a href="http://www.<?php echo NY_SITE;?>" target="_blank"><img src="http://www.<?php echo NY_SITE;?>/img/navayan-logo.jpg" alt="<?php echo NY_SITE;?>" /></a></p>
			<p><?php echo NY_PLUGIN_SUBSCRIBE_ABOUT;?></p>
			<p id="nydonate">
				<a href="<?php echo NY_DONATE_SUBSCRIBE_LINK;?>" target="_blank"><img src="https://www.paypal.com/en_US/i/btn/btn_donate_LG.gif" alt="Donate using PayPal" /></a><br />
				<?php echo NY_DONATE_TEXT;?>
			</p>
		</div>
	</div>
	
	<?php
		# Get latest posts
		include_once(ABSPATH . WPINC . '/feed.php');
		// Get a SimplePie feed object from the specified feed source.
		$rss = fetch_feed( NY_PLUGIN_URL . 'feed/' );
		if (!is_wp_error( $rss ) ) { // Checks that the object is created correctly 
			$max = $rss->get_item_quantity(8);
			$rss_items = $rss->get_items(0, $max);
      shuffle($rss_items);
		}
		if ($max > 0) :
	?>
		<div class="ny-widgets nybox">
			<h3>Awesome Posts</h3>
			<div class="ny-widgets-desc">
				<ul>
					<?php
						foreach ( $rss_items as $item ){
							echo "<li><a href='". esc_url( $item->get_permalink() ) ."' target='_blank'>". esc_html( $item->get_title() ) ."</a></li>";
						}
					?>
				</ul>
			</div>
		</div>
	<?php endif; ?>
<?php } ?>