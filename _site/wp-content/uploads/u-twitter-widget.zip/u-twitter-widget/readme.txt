=== Tweets ===
Author: Mesut Savvas
Tags: Twitter, widget, tweet, tweets, tweeter, widget, plugin, link, links, image, images, post, posts, social, media, wp, button, like, user, admin
Requires at least: 3.0
Tested up to: 3.4

== Description ==
A Practical Twitter Widget That displays the last tweets of the user of your choice.

== Installation ==
Add this plugin to the plugin folder of your WP installation, enable it and it wil pop up in the 'Widgets' section at the control panel. Here you can enter the X an Y variables.

